
CREATE DATABASE db_pengaduan;
USE db_pengaduan;

CREATE TABLE Admin(
username VARCHAR(50) PRIMARY KEY,
password VARCHAR(255)
);

CREATE TABLE Siswa(
nis INT PRIMARY KEY,
kelas VARCHAR(20)
);

CREATE TABLE Kategori(
id_kategori INT AUTO_INCREMENT PRIMARY KEY,
ket_kategori VARCHAR(50)
);

CREATE TABLE Input_Aspirasi(
id_pelaporan INT AUTO_INCREMENT PRIMARY KEY,
nis INT,
id_kategori INT,
lokasi VARCHAR(100),
ket TEXT
);

CREATE TABLE Aspirasi(
id_aspirasi INT PRIMARY KEY,
status ENUM('Menunggu','Proses','Selesai'),
feedback TEXT
);
