<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Daftar Aspirasi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
<h3>Daftar Aspirasi</h3>

<table class="table table-bordered">
<tr>
<th>No</th>
<th>Kategori</th>
<th>Lokasi</th>
<th>Keterangan</th>
<th>Status</th>
<th>Feedback</th>
</tr>

<?php
$query="SELECT ia.*,k.ket_kategori,a.status,a.feedback 
FROM Input_Aspirasi ia
JOIN Kategori k ON ia.id_kategori=k.id_kategori
LEFT JOIN Aspirasi a ON ia.id_pelaporan=a.id_aspirasi";

$data=mysqli_query($koneksi,$query);
$no=1;

while($d=mysqli_fetch_array($data)){
$status=$d['status']?$d['status']:"Menunggu";
$feedback=$d['feedback']?$d['feedback']:"-";

echo "<tr>
<td>$no</td>
<td>$d[ket_kategori]</td>
<td>$d[lokasi]</td>
<td>$d[ket]</td>
<td>$status</td>
<td>$feedback</td>
</tr>";

$no++;
}
?>

</table>
</div>
</body>
</html>
