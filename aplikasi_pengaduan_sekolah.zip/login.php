<?php
session_start();
include 'koneksi.php';

if(isset($_POST['btn_login'])){

$user=$_POST['username'];
$pass=md5($_POST['password']);

$q=mysqli_query($koneksi,"SELECT * FROM Admin WHERE username='$user' AND password='$pass'");

if(mysqli_num_rows($q)>0){
$_SESSION['status']="login";
header("location:admin_aspirasi.php");
}else{
echo "<script>alert('Login gagal');</script>";
}

}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card">
<div class="card-header">Login Admin</div>
<div class="card-body">

<form method="POST">
<input type="text" name="username" class="form-control mb-2" placeholder="Username">
<input type="password" name="password" class="form-control mb-2" placeholder="Password">

<button type="submit" name="btn_login" class="btn btn-primary">Login</button>
</form>

</div>
</div>
</div>

</body>
</html>
