<?php
include 'koneksi.php';

if (isset($_POST['btn_simpan'])) {
    $nis         = $_POST['nis'];
    $id_kategori = $_POST['id_kategori'];
    $lokasi      = $_POST['lokasi'];
    $ket         = $_POST['ket'];

    $query = "INSERT INTO Input_Aspirasi (nis, id_kategori, lokasi, ket) 
              VALUES ('$nis', '$id_kategori', '$lokasi', '$ket')";

    $simpan = mysqli_query($koneksi, $query);

    if ($simpan) {
        echo "<script>alert('Pengaduan berhasil disimpan!'); window.location='daftar_aspirasi.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Input Pengaduan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
<div class="card">
<div class="card-header bg-primary text-white">Form Pengaduan</div>
<div class="card-body">
<form method="POST">

<div class="mb-3">
<label>NIS</label>
<select name="nis" class="form-select">
<?php
$q = mysqli_query($koneksi,"SELECT * FROM Siswa");
while($d=mysqli_fetch_array($q)){
echo "<option value='$d[nis]'>$d[nis] - $d[kelas]</option>";
}
?>
</select>
</div>

<div class="mb-3">
<label>Kategori</label>
<select name="id_kategori" class="form-select">
<?php
$q = mysqli_query($koneksi,"SELECT * FROM Kategori");
while($d=mysqli_fetch_array($q)){
echo "<option value='$d[id_kategori]'>$d[ket_kategori]</option>";
}
?>
</select>
</div>

<div class="mb-3">
<label>Lokasi</label>
<input type="text" name="lokasi" class="form-control">
</div>

<div class="mb-3">
<label>Keterangan</label>
<textarea name="ket" class="form-control"></textarea>
</div>

<button type="submit" name="btn_simpan" class="btn btn-primary">Simpan</button>

</form>
</div>
</div>
</div>
</body>
</html>
