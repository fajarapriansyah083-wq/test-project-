<?php
session_start();
include 'koneksi.php';

$id=$_GET['id'];

if(isset($_POST['btn_update'])){

$status=$_POST['status'];
$feedback=$_POST['feedback'];

$q=mysqli_query($koneksi,"SELECT * FROM Aspirasi WHERE id_aspirasi='$id'");

if(mysqli_num_rows($q)>0){

mysqli_query($koneksi,"UPDATE Aspirasi SET status='$status',feedback='$feedback' WHERE id_aspirasi='$id'");

}else{

mysqli_query($koneksi,"INSERT INTO Aspirasi(id_aspirasi,status,feedback) VALUES('$id','$status','$feedback')");

}

echo "<script>alert('Update berhasil');window.location='admin_aspirasi.php';</script>";
}
?>

<form method="POST">
Status:
<select name="status">
<option>Menunggu</option>
<option>Proses</option>
<option>Selesai</option>
</select>

<br><br>

Feedback:
<textarea name="feedback"></textarea>

<br><br>

<button name="btn_update">Simpan</button>

</form>
