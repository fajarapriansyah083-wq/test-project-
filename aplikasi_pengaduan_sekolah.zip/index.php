<!DOCTYPE html>
<html>
<head>
<title>Aplikasi Pengaduan Sekolah</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container text-center mt-5">

<h2>Aplikasi Pengaduan Sarana Sekolah</h2>

<a href="input_pengaduan.php" class="btn btn-primary m-2">Input Pengaduan</a>
<a href="daftar_aspirasi.php" class="btn btn-success m-2">Lihat Aspirasi</a>
<a href="login.php" class="btn btn-dark m-2">Login Admin</a>

</div>

</body>
</html>
