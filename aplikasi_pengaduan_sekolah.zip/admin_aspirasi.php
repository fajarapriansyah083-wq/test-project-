<?php
session_start();
include 'koneksi.php';

if($_SESSION['status']!="login"){
header("location:login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
<h3>Dashboard Admin</h3>

<table class="table table-bordered">
<tr>
<th>No</th>
<th>NIS</th>
<th>Kategori</th>
<th>Lokasi</th>
<th>Status</th>
<th>Aksi</th>
</tr>

<?php

$q=mysqli_query($koneksi,"SELECT * FROM Input_Aspirasi");
$no=1;

while($d=mysqli_fetch_array($q)){

echo "<tr>
<td>$no</td>
<td>$d[nis]</td>
<td>$d[id_kategori]</td>
<td>$d[lokasi]</td>
<td>Menunggu</td>
<td><a href='update_aspirasi.php?id=$d[id_pelaporan]' class='btn btn-info btn-sm'>Update</a></td>
</tr>";

$no++;
}
?>

</table>

</div>

</body>
</html>
